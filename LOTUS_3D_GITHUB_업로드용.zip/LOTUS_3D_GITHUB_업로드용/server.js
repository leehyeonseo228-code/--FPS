const http=require('http');
const fs=require('fs');
const path=require('path');
const WebSocket=require('ws');
const PORT=process.env.PORT||8080;
const root=__dirname;
const players=new Map();
let nextId=1;
const server=http.createServer((req,res)=>{
  let p=req.url.split('?')[0];
  if(p==='/'||p==='/index.html') p='/index.html';
  const file=path.join(root,p);
  if(!file.startsWith(root)) return res.writeHead(403).end();
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);return res.end('Not found');}
    const ext=path.extname(file);
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8'};
    res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':'no-store'});res.end(data);
  });
});
const wss=new WebSocket.Server({server});
wss.on('connection',ws=>{
  const id=String(nextId++);
  players.set(id,{id,x:0,y:0,z:0,yaw:0,pitch:0,dead:false,ws});
  ws.send(JSON.stringify({type:'welcome',id}));
  ws.on('message',raw=>{
    try{
      const m=JSON.parse(raw);
      if(m.type==='state'){
        const p=players.get(id); if(!p)return;
        for(const k of ['x','y','z','yaw','pitch']) if(Number.isFinite(+m[k])) p[k]=+m[k];
        p.dead=!!m.dead;
      }
    }catch{}
  });
  ws.on('close',()=>players.delete(id));
});
setInterval(()=>{
  const out=JSON.stringify({type:'state',players:[...players.values()].map(({ws,...p})=>p)});
  for(const p of players.values()) if(p.ws.readyState===WebSocket.OPEN) p.ws.send(out);
},50);
server.listen(PORT,()=>console.log(`LOTUS server running: http://localhost:${PORT}`));
