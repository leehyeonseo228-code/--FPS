LOTUS 3D 택티컬 슈터 - GitHub 업로드용 파일

[웹으로 올리기]
1. 이 ZIP을 압축 해제합니다.
2. GitHub 저장소의 파일 추가 -> 파일 업로드에서 아래 5개 파일을 올립니다.
   index.html
   server.js
   package.json
   start-server.bat
   README.txt
3. GitHub Pages는 index.html을 웹페이지로 공개할 수 있습니다.

[중요]
GitHub Pages에서는 server.js가 실행되지 않습니다.
따라서 GitHub Pages 링크만으로는 실시간 멀티플레이 서버가 자동으로 켜지지 않습니다.
멀티플레이를 하려면 server.js를 Node.js 서버에서 실행해야 합니다.

현재 멀티플레이 브리지는 플레이어 위치/시점/사망 상태를 동기화하는 기본 프로토타입입니다.
사격, HP, 킬, 라운드, 스파이크 등 게임 판정은 아직 서버 권한 방식으로 통합되지 않았습니다.

[로컬 실행]
start-server.bat을 더블클릭 -> http://localhost:8080

[GitHub Pages에서 별도 서버에 연결]
웹 주소 뒤에 ?ws=서버주소 를 붙일 수 있습니다.
예: https://내아이디.github.io/저장소/?ws=wss://내-멀티서버.example.com
