@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js가 설치되어 있지 않습니다.
  echo https://nodejs.org/ 에서 Node.js LTS를 설치한 뒤 다시 실행하세요.
  pause
  exit /b 1
)
if not exist node_modules\ws (
  echo 필요한 패키지를 설치합니다...
  npm install
)
start "LOTUS Browser" http://localhost:8080
node server.js
pause
