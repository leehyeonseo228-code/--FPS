const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const PORT = process.env.PORT || 8080;
const ROOT = __dirname;
const server = http.createServer((req,res)=>{
  let p = req.url.split('?')[0]; if(p==='/' ) p='/index.html';
  const file=path.join(ROOT,p);
  if(!file.startsWith(ROOT)){res.writeHead(403);return res.end();}
  fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found');}
    const ext=path.extname(file); const ct=ext==='.html'?'text/html; charset=utf-8':'text/plain';
    res.writeHead(200,{'Content-Type':ct,'Cache-Control':'no-store'});res.end(data);
  });
});
const wss = new WebSocket.Server({server});
const players=new Map(); let nextId=1;
wss.on('connection',ws=>{
  const id=String(nextId++); players.set(id,{id,x:0,y:0,z:28,yaw:0});
  ws.send(JSON.stringify({type:'welcome',id}));
  ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
    const p=players.get(id); if(!p)return;
    if(m.type==='state'){p.x=Number(m.x)||0;p.y=Number(m.y)||0;p.z=Number(m.z)||0;p.yaw=Number(m.yaw)||0;p.dead=!!m.dead;}
  });
  ws.on('close',()=>players.delete(id));
});
setInterval(()=>{const msg=JSON.stringify({type:'state',players:[...players.values()]});wss.clients.forEach(c=>{if(c.readyState===1)c.send(msg)});},50);
server.listen(PORT,()=>console.log(`LOTUS server running: http://localhost:${PORT}`));
