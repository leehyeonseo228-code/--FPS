@echo off
cd /d "%~dp0"
node -v >nul 2>&1 || (echo Node.js가 필요합니다. https://nodejs.org/ 에서 설치하세요.&pause&exit /b)
if not exist node_modules\ws npm install
start http://localhost:8080
node server.js
pause
